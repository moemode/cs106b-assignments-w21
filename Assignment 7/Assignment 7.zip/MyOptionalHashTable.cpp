#include "MyOptionalHashTable.h"
#include "GUI/SimpleTest.h"
using namespace std;

MyOptionalHashTable::MyOptionalHashTable(HashFunction<std::string> hashFn) {
    /* OPTIONAL: Delete this comment and the next line, then implement this function. */
    (void) hashFn;
}

MyOptionalHashTable::~MyOptionalHashTable() {
    /* OPTIONAL: Delete this comment, then implement this function. */
}

int MyOptionalHashTable::size() const {
    /* OPTIONAL: Delete this comment and the next lines, then implement this function. */
    return -1;
}

bool MyOptionalHashTable::isEmpty() const {
    /* OPTIONAL: Delete this comment and the next lines, then implement this function. */
    return false;
}

bool MyOptionalHashTable::insert(const string& elem) {
    /* OPTIONAL: Delete this comment and the next lines, then implement this function. */
    (void) elem;
    return false;
}

bool MyOptionalHashTable::contains(const string& elem) const {
    /* OPTIONAL: Delete this comment and the next lines, then implement this function. */
    (void) elem;
    return false;
}

bool MyOptionalHashTable::remove(const string& elem) {
    /* OPTIONAL: Delete this comment and the next lines, then implement this function. */
    (void) elem;
    return false;
}

void MyOptionalHashTable::printDebugInfo() const {
    /* OPTIONAL: Remove this comment and implement this function. */
}

/* OPTIONAL: Add custom test cases below this point. */
