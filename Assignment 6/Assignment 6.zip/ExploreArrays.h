#ifndef ExploreArrays_Included
#define ExploreArrays_Included

void exploreArrays();

#endif
