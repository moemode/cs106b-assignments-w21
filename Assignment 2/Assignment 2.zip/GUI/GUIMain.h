#ifndef GUIMain_Included
#define GUIMain_Included

/* Locks/unlocks all demo option buttons. Should only be called from the main GUI thread. */
void setDemoOptionsEnabled(bool isEnabled);

#endif
